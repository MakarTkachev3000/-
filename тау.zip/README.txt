Overleaf project for TАУ Task 1 (Ekselby method).

Steps:
1) Upload this ZIP to Overleaf (New Project -> Upload Project).
2) Replace k2_plot.pdf with your generated plot (or keep name consistent).
3) Fill in numerical results for Dx and k^(2) in section 'Пример'.
4) Compile.
